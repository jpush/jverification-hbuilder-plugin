//
//  JVerificationModule.h
//  UniPluginJVerification
//
//  Created by 李攀 on 2020/1/10.
//  Copyright © 2020 李攀. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WXModuleProtocol.h"
#import "WeexSDK.h"
NS_ASSUME_NONNULL_BEGIN

@interface JVerificationModule : NSObject <WXModuleProtocol>

@end

NS_ASSUME_NONNULL_END
